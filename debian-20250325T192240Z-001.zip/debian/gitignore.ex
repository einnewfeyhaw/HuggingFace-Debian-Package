/*.substvars
/.debhelper/
/debhelper-build-stamp
/files
/tmp/
