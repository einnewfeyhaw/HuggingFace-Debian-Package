Document: python3-huggingface-hub
Title: Debian python3-huggingface-hub Manual
Author: <insert document author here>
Abstract: This manual describes what python3-huggingface-hub is
 and how it can be used to
 manage online manuals on Debian systems.
Section: unknown

Format: debiandoc-sgml
Files: /usr/share/doc/python3-huggingface-hub/python3-huggingface-hub.sgml.gz

Format: postscript
Files: /usr/share/doc/python3-huggingface-hub/python3-huggingface-hub.ps.gz

Format: text
Files: /usr/share/doc/python3-huggingface-hub/python3-huggingface-hub.text.gz

Format: HTML
Index: /usr/share/doc/python3-huggingface-hub/html/index.html
Files: /usr/share/doc/python3-huggingface-hub/html/*.html
