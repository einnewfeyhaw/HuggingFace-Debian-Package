# Example file for upstream/metadata.
# See https://wiki.debian.org/UpstreamMetadata for more info/fields.
# Below an example based on a github project.

# Bug-Database: https://github.com/<user>/python3-huggingface-hub/issues
# Bug-Submit: https://github.com/<user>/python3-huggingface-hub/issues/new
# Changelog: https://github.com/<user>/python3-huggingface-hub/blob/master/CHANGES
# Documentation: https://github.com/<user>/python3-huggingface-hub/wiki
# Repository-Browse: https://github.com/<user>/python3-huggingface-hub
# Repository: https://github.com/<user>/python3-huggingface-hub.git
