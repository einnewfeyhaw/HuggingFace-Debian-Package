---
{{card_data}}
---

# {{ model_name | default("MyModelName", true)}}

{{ some_data }}
