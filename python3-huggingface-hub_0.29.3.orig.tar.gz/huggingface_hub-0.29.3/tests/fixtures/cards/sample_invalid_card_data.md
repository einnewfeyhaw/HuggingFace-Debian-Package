---
[]
---

# invalid-card-data

This card should fail when trying to load it in because the card data between the `---` is a list instead of a dict.
