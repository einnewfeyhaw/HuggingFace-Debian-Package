# MyCoolModel

In this example, we don't have any metadata at the top of the file. In cases like these, `CardData` should be instantiated as empty.
