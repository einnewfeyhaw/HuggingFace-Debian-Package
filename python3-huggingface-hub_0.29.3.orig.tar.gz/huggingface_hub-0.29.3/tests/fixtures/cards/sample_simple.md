---
language:
- en
license: mit
library_name: pytorch-lightning
tags:
- pytorch
- image-classification
datasets:
- beans
metrics:
- acc
---

# my-cool-model

## Model description

You can embed local or remote images using `![](...)`
